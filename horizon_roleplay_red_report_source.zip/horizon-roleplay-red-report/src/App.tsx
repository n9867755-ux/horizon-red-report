import { FormEvent, useCallback, useEffect, useMemo, useState } from 'react'
import { createClient, Session } from '@supabase/supabase-js'
import { AlertCircle, ArrowUpRight, CheckCircle2, ClipboardList, Eye, FileWarning, LogIn, LogOut, MessageSquareText, Plus, ShieldCheck, X } from 'lucide-react'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string | undefined
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined
const supabase = supabaseUrl && supabaseKey ? createClient(supabaseUrl, supabaseKey) : null

type Report = {
  id: string
  player_name: string
  category: string
  title: string
  details: string
  evidence_url: string | null
  status: 'Open' | 'In Review' | 'Resolved'
  admin_reply: string | null
  created_at: string
  updated_at: string
}
const categories = ['Player Report', 'Admin / Staff Complaint', 'Rule Violation', 'Bug / Technical Issue', 'Other']
const filters = ['All Reports', 'Open', 'In Review', 'Resolved']

function dateLabel(value: string) {
  return new Intl.DateTimeFormat('en', { dateStyle: 'medium' }).format(new Date(value))
}
function statusClass(status: string) {
  return status === 'Resolved' ? 'resolved' : status === 'In Review' ? 'review' : 'open'
}

export default function App() {
  const [reports, setReports] = useState<Report[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [filter, setFilter] = useState('All Reports')
  const [showForm, setShowForm] = useState(false)
  const [session, setSession] = useState<Session | null>(null)
  const [isAdmin, setIsAdmin] = useState(false)
  const [showLogin, setShowLogin] = useState(false)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [authBusy, setAuthBusy] = useState(false)
  const [selected, setSelected] = useState<Report | null>(null)
  const [reply, setReply] = useState('')
  const [status, setStatus] = useState<Report['status']>('Open')
  const [adminBusy, setAdminBusy] = useState(false)

  const loadReports = useCallback(async () => {
    if (!supabase) { setLoading(false); return }
    setLoading(true)
    const { data, error: queryError } = await supabase.from('reports').select('*').order('created_at', { ascending: false })
    if (queryError) setError(queryError.message)
    else { setReports((data ?? []) as Report[]); setError('') }
    setLoading(false)
  }, [])

  const checkAdmin = useCallback(async (currentSession: Session | null) => {
    if (!supabase || !currentSession) { setIsAdmin(false); return }
    const { data, error: roleError } = await supabase.rpc('is_red_report_admin')
    setIsAdmin(!roleError && data === true)
  }, [])

  useEffect(() => {
    if (!supabase) { setLoading(false); return }
    let mounted = true
    supabase.auth.getSession().then(async ({ data }) => {
      if (!mounted) return
      setSession(data.session)
      await checkAdmin(data.session)
      await loadReports()
    })
    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      setSession(nextSession)
      // Defer API calls until after the auth callback returns.
      window.setTimeout(() => { if (mounted) void checkAdmin(nextSession) }, 0)
    })
    const channel = supabase.channel('public-reports-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'reports' }, () => { void loadReports() })
      .subscribe()
    return () => { mounted = false; listener.subscription.unsubscribe(); void supabase.removeChannel(channel) }
  }, [checkAdmin, loadReports])

  const visibleReports = useMemo(() => reports.filter(r => filter === 'All Reports' || r.status === filter), [reports, filter])
  const openCount = reports.filter(r => r.status === 'Open' || r.status === 'In Review').length
  const resolvedCount = reports.filter(r => r.status === 'Resolved').length

  async function submitReport(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!supabase) return
    const formElement = event.currentTarget
    const form = new FormData(formElement)
    const record = {
      player_name: String(form.get('player_name') ?? '').trim(),
      category: String(form.get('category') ?? ''),
      title: String(form.get('title') ?? '').trim(),
      details: String(form.get('details') ?? '').trim(),
      evidence_url: String(form.get('evidence_url') ?? '').trim() || null,
      status: 'Open',
      admin_reply: null
    }
    const { error: insertError } = await supabase.from('reports').insert(record)
    if (insertError) { setNotice(`Could not submit report: ${insertError.message}`); return }
    formElement.reset()
    setShowForm(false)
    setFilter('All Reports')
    setNotice('Your report has been published. Thank you for helping the community.')
    await loadReports()
  }

  async function signIn(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!supabase) return
    setAuthBusy(true); setNotice('')
    const { data, error: signInError } = await supabase.auth.signInWithPassword({ email, password })
    if (signInError) setNotice(`Sign-in failed: ${signInError.message}`)
    else {
      setSession(data.session)
      await checkAdmin(data.session)
      if (!data.session) setNotice('Sign-in did not create a session.')
      else {
        const { data: adminResult } = await supabase.rpc('is_red_report_admin')
        if (adminResult !== true) {
          await supabase.auth.signOut()
          setSession(null); setIsAdmin(false)
          setNotice('This account is not authorised as a Red Report admin.')
        } else {
          setShowLogin(false); setEmail(''); setPassword('')
          setNotice('Signed in to admin mode.')
        }
      }
    }
    setAuthBusy(false)
  }

  async function signOut() {
    if (!supabase) return
    await supabase.auth.signOut()
    setSession(null); setIsAdmin(false); setSelected(null)
    setNotice('You have signed out.')
  }

  function editReport(report: Report) {
    setSelected(report); setReply(report.admin_reply ?? ''); setStatus(report.status)
  }

  async function saveAdminReply(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!supabase || !selected || !isAdmin) return
    setAdminBusy(true); setNotice('')
    const { error: updateError } = await supabase.from('reports').update({
      admin_reply: reply.trim() || null,
      status,
      updated_at: new Date().toISOString()
    }).eq('id', selected.id)
    if (updateError) setNotice(`Could not save response: ${updateError.message}`)
    else {
      setNotice('Official admin response saved.')
      setSelected(null)
      await loadReports()
    }
    setAdminBusy(false)
  }

  if (!supabase) return <div className="setup"><div className="brand-mark">HR</div><p className="eyebrow">HORIZON ROLEPLAY</p><h1>Red Report</h1><h2>Connect your Supabase project to launch.</h2><p>Create <code>.env.local</code> from <code>.env.example</code>, then add your Supabase URL and publishable/anon key. Follow the README for database setup and deployment.</p><div className="setup-steps"><span>01 · Create Supabase project</span><span>02 · Run supabase/schema.sql</span><span>03 · Add environment variables</span></div></div>

  return <div className="app-shell">
    <header className="topbar"><a className="brand" href="#"><span className="brand-mark">HR</span><span><b>HORIZON ROLEPLAY</b><small>COMMUNITY PORTAL</small></span></a><nav><a href="#reports"><Eye size={16}/> Public reports</a>{isAdmin ? <button className="btn btn-outline" onClick={signOut}><LogOut size={16}/> Admin sign out</button> : <button className="btn btn-outline" onClick={() => setShowLogin(true)}><LogIn size={16}/> Admin login</button>}<button className="btn btn-primary" onClick={() => setShowForm(v => !v)}><Plus size={17}/> Submit report</button></nav></header>
    <main>
      <section className="hero">
        <div className="hero-copy"><div className="eyebrow"><span className="live-dot"/> OFFICIAL COMMUNITY REPORTING PORTAL</div><h1>Make your voice<br/><em>count.</em></h1><p>Report rule violations, raise concerns, and follow official staff responses. A fair roleplay community starts with accountability.</p><div className="hero-actions"><button className="btn btn-primary btn-large" onClick={() => setShowForm(true)}><FileWarning size={18}/> Create a red report</button><a className="btn btn-ghost btn-large" href="#reports">Browse reports <ArrowUpRight size={17}/></a></div><div className="hero-note"><ShieldCheck size={16}/> Public transparency. Admin-only official replies.</div></div>
        <div className="hero-visual"><div className="visual-grid"/><div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="shield"><ShieldCheck size={65} strokeWidth={1.4}/></div><div className="floating-card card-a"><span className="mini-icon"><ClipboardList size={17}/></span><span><b>Report received</b><small>Community queue</small></span><span className="tiny-status"/></div><div className="floating-card card-b"><span className="mini-icon teal"><MessageSquareText size={17}/></span><span><b>Official response</b><small>Admin verified</small></span><CheckCircle2 size={18} className="teal-text"/></div><div className="visual-label">HORIZON · TRUST & FAIR PLAY</div></div>
      </section>
      <section className="stats"><div><span className="stat-icon"><ClipboardList size={18}/></span><span><small>TOTAL REPORTS</small><strong>{reports.length}</strong></span></div><div><span className="stat-icon amber"><AlertCircle size={18}/></span><span><small>ACTIVE CASES</small><strong>{openCount}</strong></span></div><div><span className="stat-icon teal"><CheckCircle2 size={18}/></span><span><small>RESOLVED</small><strong>{resolvedCount}</strong></span></div><div className="stat-note">Updated live <span className="live-dot"/></div></section>

      {showForm && <section className="form-panel" id="report-form"><div className="panel-heading"><div><span className="eyebrow">COMMUNITY SUBMISSION</span><h2>Submit a red report</h2><p>Give the moderation team clear, factual information.</p></div><button className="icon-button" onClick={() => setShowForm(false)} aria-label="Close form"><X/></button></div><form onSubmit={submitReport} className="report-form"><div className="field"><label>Player name / username *</label><input name="player_name" required minLength={2} maxLength={60} placeholder="Your in-game name"/></div><div className="field"><label>Report category *</label><select name="category" required defaultValue=""><option value="" disabled>Select a category</option>{categories.map(c => <option key={c}>{c}</option>)}</select></div><div className="field full"><label>Report title *</label><input name="title" required minLength={5} maxLength={120} placeholder="Briefly describe the issue"/></div><div className="field full"><label>What happened? *</label><textarea name="details" required minLength={10} maxLength={3000} rows={5} placeholder="Include relevant names, date/time, server details, and a factual explanation. Do not include passwords or private personal information."/></div><div className="field full"><label>Evidence link <span>(optional)</span></label><input name="evidence_url" type="url" placeholder="https://link-to-evidence.example"/></div><div className="form-bottom"><p>By submitting, you understand this report and any evidence link will be publicly visible.</p><button className="btn btn-primary" type="submit">Publish report <ArrowUpRight size={16}/></button></div></form></section>}

      {notice && <div className="notice" role="status"><span>{notice}</span><button onClick={() => setNotice('')} aria-label="Dismiss notice"><X size={16}/></button></div>}
      {error && <div className="notice error"><AlertCircle size={18}/><span>Could not load reports: {error}. Check your Supabase schema and API configuration.</span></div>}

      <section id="reports" className="reports-section"><div className="section-top"><div><span className="eyebrow">OPEN COMMUNITY RECORD</span><h2>Public reports <span className="count-pill">{reports.length}</span></h2><p>Every report is visible. Official responses are clearly marked.</p></div><div className="filter-group">{filters.map(f => <button key={f} className={filter === f ? 'filter active' : 'filter'} onClick={() => setFilter(f)}>{f}</button>)}</div></div>
        {loading ? <div className="empty-state"><div className="spinner"/><p>Loading community reports…</p></div> : visibleReports.length === 0 ? <div className="empty-state"><ClipboardList size={30}/><h3>No reports found</h3><p>There are no reports in this category yet.</p><button className="btn btn-outline" onClick={() => setShowForm(true)}>Submit the first report</button></div> : <div className="report-list">{visibleReports.map((report, index) => <article className="report-card" key={report.id}><div className="report-number">{String(index + 1).padStart(2, '0')}</div><div className="report-main"><div className="report-meta"><span className={`status status-${statusClass(report.status)}`}><i/>{report.status}</span><span className="category-label">{report.category}</span><span className="report-date">{dateLabel(report.created_at)}</span></div><h3>{report.title}</h3><p className="report-details">{report.details}</p><div className="report-byline">Submitted by <b>{report.player_name}</b><span>·</span> ID {report.id.slice(0, 8).toUpperCase()}</div>{report.evidence_url && <a className="evidence-link" href={report.evidence_url} target="_blank" rel="noreferrer">View evidence <ArrowUpRight size={14}/></a>}
            {report.admin_reply && <div className="official-reply"><div className="reply-icon"><ShieldCheck size={17}/></div><div><div className="reply-label">OFFICIAL ADMIN RESPONSE <span><CheckCircle2 size={13}/> VERIFIED STAFF</span></div><p>{report.admin_reply}</p></div></div>}
            {!report.admin_reply && <div className="awaiting-reply"><MessageSquareText size={15}/> Awaiting official admin response</div>}
          </div>{isAdmin && <button className="manage-btn" onClick={() => editReport(report)}>Manage <ArrowUpRight size={14}/></button>}</article>)}</div>}
      </section>
      <section className="guidelines"><div className="guideline-icon"><ShieldCheck size={25}/></div><div><h3>Keep Horizon fair for everyone</h3><p>Submit honest reports, share relevant evidence, and stay respectful. Harassment, threats, doxxing, and knowingly false reports are not acceptable.</p></div><button className="btn btn-ghost" onClick={() => setShowForm(true)}>Report an issue <ArrowUpRight size={16}/></button></section>
    </main>
    <footer><a className="brand footer-brand" href="#"><span className="brand-mark">HR</span><span><b>HORIZON ROLEPLAY</b><small>RED REPORT PORTAL</small></span></a><span>Built for fairness. Powered by community accountability.</span><span className="footer-status"><i/> REPORT SYSTEM ONLINE</span></footer>

    {showLogin && <div className="modal-backdrop" role="presentation" onMouseDown={e => { if (e.target === e.currentTarget) setShowLogin(false) }}><section className="modal" role="dialog" aria-modal="true" aria-labelledby="login-title"><button className="modal-close" onClick={() => setShowLogin(false)} aria-label="Close"><X/></button><div className="modal-emblem"><ShieldCheck size={27}/></div><span className="eyebrow">STAFF ACCESS</span><h2 id="login-title">Admin login</h2><p>Sign in with an authorised Horizon staff account.</p><form onSubmit={signIn}><div className="field"><label>Staff email</label><input type="email" autoComplete="username" required value={email} onChange={e => setEmail(e.target.value)} placeholder="staff@example.com"/></div><div className="field"><label>Password</label><input type="password" autoComplete="current-password" required value={password} onChange={e => setPassword(e.target.value)} placeholder="Your password"/></div><button className="btn btn-primary full-btn" type="submit" disabled={authBusy}>{authBusy ? 'Signing in…' : 'Secure sign in'} <LogIn size={16}/></button></form><div className="modal-security"><ShieldCheck size={15}/> Admin permissions are verified by the database.</div></section></div>}

    {selected && isAdmin && <div className="modal-backdrop" role="presentation"><section className="modal admin-modal" role="dialog" aria-modal="true" aria-labelledby="manage-title"><button className="modal-close" onClick={() => setSelected(null)} aria-label="Close"><X/></button><span className="eyebrow">MODERATION TOOLS</span><h2 id="manage-title">Manage report</h2><p className="manage-subtitle">{selected.title}</p><form onSubmit={saveAdminReply}><div className="field"><label>Report status</label><select value={status} onChange={e => setStatus(e.target.value as Report['status'])}><option>Open</option><option>In Review</option><option>Resolved</option></select></div><div className="field"><label>Official admin response</label><textarea value={reply} onChange={e => setReply(e.target.value)} maxLength={3000} rows={6} placeholder="Write a factual, professional response…"/></div><button className="btn btn-primary full-btn" disabled={adminBusy}>{adminBusy ? 'Saving…' : 'Save official response'} <CheckCircle2 size={16}/></button><p className="fine-print">Your authenticated admin account will be used to save this change.</p></form></section></div>}
  </div>
}