-- Horizon Roleplay Red Report
-- Run this whole file in Supabase Dashboard > SQL Editor.
-- Public visitors can read and submit reports. Only user IDs listed in admin_users can update reports.
-- Never put a Supabase service-role key in the browser app.

create extension if not exists pgcrypto;

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  added_at timestamptz not null default now()
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  player_name text not null check (char_length(player_name) between 2 and 60),
  category text not null check (category in ('Player Report', 'Admin / Staff Complaint', 'Rule Violation', 'Bug / Technical Issue', 'Other')),
  title text not null check (char_length(title) between 5 and 120),
  details text not null check (char_length(details) between 10 and 3000),
  evidence_url text null check (evidence_url is null or (char_length(evidence_url) <= 1000 and evidence_url ~* '^https?://')),
  status text not null default 'Open' check (status in ('Open', 'In Review', 'Resolved')),
  admin_reply text null check (admin_reply is null or char_length(admin_reply) <= 3000),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists reports_created_at_idx on public.reports (created_at desc);
create index if not exists reports_status_idx on public.reports (status);

create or replace function public.is_red_report_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.admin_users a
    where a.user_id = (select auth.uid())
  );
$$;

revoke all on function public.is_red_report_admin() from public;
grant execute on function public.is_red_report_admin() to anon, authenticated;

alter table public.reports enable row level security;
alter table public.admin_users enable row level security;

-- Admin membership is intentionally not readable or writable from the client.
revoke all on public.admin_users from anon, authenticated;

drop policy if exists "Anyone can view public reports" on public.reports;
create policy "Anyone can view public reports"
on public.reports for select
to anon, authenticated
using (true);

drop policy if exists "Visitors can submit open reports" on public.reports;
create policy "Visitors can submit open reports"
on public.reports for insert
to anon, authenticated
with check (
  status = 'Open'
  and admin_reply is null
);

drop policy if exists "Only admins can update reports" on public.reports;
create policy "Only admins can update reports"
on public.reports for update
to authenticated
using (public.is_red_report_admin())
with check (public.is_red_report_admin());

-- No delete policy: reports cannot be deleted through the public client.
grant select, insert on public.reports to anon, authenticated;
grant update on public.reports to authenticated;

-- After creating an admin account in Authentication > Users, add that user's UUID:
-- insert into public.admin_users (user_id) values ('PASTE-AUTH-USER-UUID-HERE');
-- Only run this statement for trusted staff. Do not expose admin_users management to the website.
