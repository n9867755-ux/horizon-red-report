# Horizon Roleplay — Red Report

A public complaint/report portal for a gaming roleplay community.

## What it does

- Anyone can view submitted reports and official admin replies.
- Anyone can submit a report without creating an account.
- Only authenticated users whose UUID is explicitly added to `public.admin_users` can update report status or publish admin replies.
- Report data is stored in Supabase Postgres and shared across devices.
- Row Level Security (RLS) is the security boundary. The website does not rely on hiding admin controls in the UI.

## 1. Create the shared database

1. Create a project at [Supabase](https://supabase.com/).
2. Open **SQL Editor** in the Supabase dashboard.
3. Paste and run all of `supabase/schema.sql`.
4. Open **Project Settings → API** (or **Connect**) and copy the Project URL and publishable/anon key. These are designed for browser use when RLS is configured. **Never use the `service_role` secret in this frontend.**

## 2. Configure the app locally

1. Install Node.js 20 or later.
2. Copy `.env.example` to `.env.local`.
3. Set:
   - `VITE_SUPABASE_URL` to your Supabase project URL.
   - `VITE_SUPABASE_ANON_KEY` to your Supabase publishable/anon key.
4. In this project folder, run:

   ```bash
   npm install
   npm run dev
   ```

5. Open the local URL printed by Vite.

## 3. Create admin accounts safely

1. In Supabase, open **Authentication → Users** and create/invite the trusted staff member. Disable public sign-ups in **Authentication → Settings** if you want only dashboard-created accounts.
2. Copy the user's UUID from the Users list.
3. In SQL Editor, run this with the real UUID:

   ```sql
   insert into public.admin_users (user_id)
   values ('PASTE-AUTH-USER-UUID-HERE');
   ```

4. Repeat only for trusted administrators. Remove an admin by deleting their row from `public.admin_users`.
5. Admins use the **Admin login** button on the site. Supabase verifies their email/password; the database independently enforces admin permissions.

Recommended: enable email confirmation, use strong unique passwords, and configure password recovery / SMTP in Supabase before launch. Do not share admin accounts.

## 4. Deploy publicly with Vercel

1. Push this folder to a private or public GitHub repository.
2. Import the repository at [Vercel](https://vercel.com/).
3. Framework preset: **Vite**. Build command: `npm run build`. Output directory: `dist`.
4. Add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` under Vercel **Project → Settings → Environment Variables** for Production (and Preview if needed).
5. Redeploy.
6. In Supabase **Authentication → URL Configuration**, set the Site URL to your deployed domain and add the deployed domain (and local dev URL, if needed) to Redirect URLs.
7. Open the public domain on two different devices and submit a test report to verify shared data.

## Before launch

- Configure Supabase email/SMTP and password reset redirects.
- Set up moderation rules and a process for abusive, false, or privacy-violating reports.
- Add CAPTCHA / bot protection and rate limits for anonymous report submissions; this starter does not include them.
- Set a retention and deletion policy, and tell players not to post passwords, addresses, or other sensitive personal information.
- Consider requiring evidence for certain categories.
- Test policies with a non-admin account and an anonymous browser. A normal user must not be able to change a report's status or reply.
- Keep database backups enabled.

## Security model and limitations

- Public report text and evidence URLs are visible to everyone by design. Do not use this system for confidential cases.
- The browser only contains the Supabase publishable/anon key. RLS protects updates.
- Admin status is stored in `admin_users`, not in browser-controlled profile fields.
- This project uses direct Supabase client access, so anonymous submission is intentionally open. Abuse controls (CAPTCHA/rate limiting) are important before a public launch.
- This is a deployable starter, not a managed hosting account: you must create Supabase/Vercel projects and configure their keys and domain.
